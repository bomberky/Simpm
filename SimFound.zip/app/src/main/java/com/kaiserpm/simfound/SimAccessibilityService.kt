package com.kaiserpm.simfound

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class SimAccessibilityService : AccessibilityService() {
    override fun onServiceConnected() { Bot.a11y = this }
    override fun onUnbind(intent: Intent?): Boolean {
        if (Bot.a11y === this) Bot.a11y = null
        return super.onUnbind(intent)
    }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    /** Быстрое нажатие по долям экрана. */
    fun tap(p: FloatArray) {
        val (w, h) = U.screen(this)
        val path = Path().apply { moveTo(p[0] * w, p[1] * h) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 1)).build()
        dispatchGesture(g, null, null)
    }

    private fun findEditable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isEditable) return n
        for (i in 0 until n.childCount) {
            val r = findEditable(n.getChild(i))
            if (r != null) return r
        }
        return null
    }

    fun hasEditable(): Boolean = findEditable(rootInActiveWindow) != null

    /** Вводит номер прямо в поле, без клавиатуры, и отправляет (Enter). */
    fun enter(num: String): Boolean {
        val e = findEditable(rootInActiveWindow) ?: return false
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, num)
        e.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
        if (Build.VERSION.SDK_INT >= 30) {
            e.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
        }
        return true
    }
}
