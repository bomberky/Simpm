package com.kaiserpm.simfound

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/** База данных результатов: номер -> free / busy */
object Store {
    private var db: SQLiteDatabase? = null
    private class H(c: Context) : SQLiteOpenHelper(c, "sim.db", null, 1) {
        override fun onCreate(d: SQLiteDatabase) {
            d.execSQL("CREATE TABLE r(num TEXT PRIMARY KEY, status TEXT, ts INTEGER)")
        }
        override fun onUpgrade(d: SQLiteDatabase, o: Int, n: Int) {}
    }
    @Synchronized
    fun save(ctx: Context, num: String, status: String) {
        if (db == null) db = H(ctx.applicationContext).writableDatabase
        db!!.execSQL("INSERT OR REPLACE INTO r VALUES(?,?,?)", arrayOf(num, status, System.currentTimeMillis()))
    }
}
