package com.kaiserpm.simfound

/**
 * Все координаты и цвета-маркеры экранов игры в долях экрана (0..1).
 * Сняты со скриншотов 2340x1080. Если игра сдвинет интерфейс — правится только этот файл.
 */
object L {
    // маркер: x, y, r, g, b
    val NOFUNDS = listOf(  // окно «Недостаточно средств» (розовая кнопка «Испытайте удачу»)
        floatArrayOf(0.342f, 0.722f, 202f, 113f, 255f),
        floatArrayOf(0.470f, 0.782f, 202f, 113f, 255f))
    val CONFIRM_NUM = listOf(  // «Подтверждение… приобрести номер» (жёлтая «Покупка»)
        floatArrayOf(0.3996f, 0.583f, 253f, 206f, 58f),
        floatArrayOf(0.487f, 0.643f, 247f, 200f, 52f))
    val CONFIRM_SVC = listOf(  // «ПОДТВЕРЖДЕНИЕ ПОКУПКИ» (жёлтая кнопка 200 GC)
        floatArrayOf(0.502f, 0.792f, 249f, 204f, 43f),
        floatArrayOf(0.632f, 0.847f, 249f, 204f, 43f))

    // точки нажатия
    val PHONE_ROW = floatArrayOf(0.470f, 0.659f)   // строка «Номер телефона» во вкладке «Услуги»
    val SVC_BUY = floatArrayOf(0.567f, 0.819f)     // жёлтая кнопка «200 GC»
    val NUM_BUY = floatArrayOf(0.444f, 0.614f)     // кнопка «Покупка»
    val CLOSE = floatArrayOf(0.721f, 0.220f)       // крестик в «Недостаточно средств»
}
