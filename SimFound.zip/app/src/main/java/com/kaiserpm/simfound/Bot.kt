package com.kaiserpm.simfound

import android.content.Context
import android.os.SystemClock

/** Основной цикл перебора. Работает по состояниям экрана, без фиксированных пауз. */
object Bot {
    const val NONE = 0
    const val CONFIRM_SVC = 1
    const val CONFIRM_NUM = 2
    const val NOFUNDS = 3

    @Volatile var state = NONE
    @Volatile var running = false
    @Volatile var a11y: SimAccessibilityService? = null

    var onStatus: ((String) -> Unit)? = null
    var onProgress: ((Int, Int, Int) -> Unit)? = null
    var onFinish: ((List<String>) -> Unit)? = null

    private fun waitFor(s: Int, ms: Long): Boolean {
        val end = SystemClock.uptimeMillis() + ms
        while (running && SystemClock.uptimeMillis() < end) {
            if (state == s) return true
            SystemClock.sleep(2)
        }
        return running && state == s
    }

    private fun waitLeave(s: Int, ms: Long) {
        val end = SystemClock.uptimeMillis() + ms
        while (running && SystemClock.uptimeMillis() < end && state == s) SystemClock.sleep(2)
    }

    /** Открывает окно ввода номера: «Номер телефона» -> подтверждение покупки (200 GC). */
    private fun openInput(svc: SimAccessibilityService): Boolean {
        if (state != CONFIRM_SVC) {
            svc.tap(L.PHONE_ROW)
            if (!waitFor(CONFIRM_SVC, 1500)) return false
        }
        svc.tap(L.SVC_BUY)
        val end = SystemClock.uptimeMillis() + 1500
        while (running && SystemClock.uptimeMillis() < end) {
            if (svc.hasEditable()) return true
            SystemClock.sleep(30)
        }
        return false
    }

    fun start(ctx: Context) {
        if (running) return
        val svc = a11y
        if (svc == null) { onStatus?.invoke("Включите службу «SIMFOUND» в настройках специальных возможностей"); return }
        running = true
        Thread { run(ctx.applicationContext, svc) }.start()
    }

    fun stop() { running = false }

    private fun run(ctx: Context, svc: SimAccessibilityService) {
        val nums = U.numbers(ctx)
        val free = ArrayList<String>()
        onStatus?.invoke("Работаю… не касайтесь экрана")
        try {
            for ((i, n) in nums.withIndex()) {
                if (!running) break
                if (!svc.enter(n)) {
                    if (!openInput(svc) || !svc.enter(n)) {
                        onStatus?.invoke("Не найдено поле ввода номера. Откройте «Услуги» и запустите заново")
                        break
                    }
                }
                if (waitFor(CONFIRM_NUM, 1000)) {
                    svc.tap(L.NUM_BUY)
                    if (waitFor(NOFUNDS, 1500)) {
                        free.add(n)
                        Store.save(ctx, n, "free")
                        svc.tap(L.CLOSE)
                        waitLeave(NOFUNDS, 800)
                    } else Store.save(ctx, n, "busy")
                } else Store.save(ctx, n, "busy")
                onProgress?.invoke(i + 1, nums.size, free.size)
            }
        } finally {
            running = false
            onFinish?.invoke(free)
        }
    }
}
