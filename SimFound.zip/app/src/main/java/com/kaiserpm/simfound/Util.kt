package com.kaiserpm.simfound

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import android.util.DisplayMetrics
import android.view.WindowManager
import java.io.File

object U {
    const val KEY = "kaiserpm"
    private const val TG = "aHR0cHM6Ly90Lm1lL2thaXNlcnBt"
    fun tg(): String = String(Base64.decode(TG, Base64.DEFAULT))

    fun screen(ctx: Context): Pair<Int, Int> {
        val m = DisplayMetrics()
        @Suppress("DEPRECATION")
        (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(m)
        return Pair(maxOf(m.widthPixels, m.heightPixels), minOf(m.widthPixels, m.heightPixels))
    }

    fun bg(ctx: Context, sample: Int): Bitmap? = try {
        ctx.assets.open("bg.jpg").use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        }
    } catch (e: Exception) { null }

    // ---- список номеров ----
    private fun f(ctx: Context) = File(ctx.filesDir, "numbers.txt")
    fun rawList(ctx: Context): String =
        if (f(ctx).exists()) f(ctx).readText()
        else ctx.assets.open("numbers.txt").bufferedReader().readText()
    fun saveList(ctx: Context, text: String) = f(ctx).writeText(text)
    fun numbers(ctx: Context): List<String> =
        Regex("\\d{6}").findAll(rawList(ctx)).map { it.value }.distinct().toList()
}
