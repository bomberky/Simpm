package com.kaiserpm.simfound

import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.HandlerThread
import kotlin.math.abs

/** Непрерывно читает кадры экрана и определяет, какое окно игры сейчас показано. */
class Capture(private val mp: MediaProjection, w: Int, h: Int, dpi: Int) {
    private val thread = HandlerThread("cap").apply { start() }
    private val handler = Handler(thread.looper)
    private val reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
    private val vd: VirtualDisplay

    init {
        mp.registerCallback(object : MediaProjection.Callback() {}, handler)
        vd = mp.createVirtualDisplay("sf", w, h, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.surface, null, handler)
        reader.setOnImageAvailableListener({ r ->
            val img = try { r.acquireLatestImage() } catch (e: Exception) { null }
            if (img != null) {
                try { Bot.state = classify(img) } finally { img.close() }
            }
        }, handler)
    }

    private fun classify(img: Image): Int {
        val pl = img.planes[0]
        val buf = pl.buffer
        val rs = pl.rowStride
        val ps = pl.pixelStride
        fun hit(m: List<FloatArray>): Boolean {
            for (p in m) {
                val x = (p[0] * img.width).toInt().coerceIn(0, img.width - 1)
                val y = (p[1] * img.height).toInt().coerceIn(0, img.height - 1)
                val o = y * rs + x * ps
                val r = buf.get(o).toInt() and 0xFF
                val g = buf.get(o + 1).toInt() and 0xFF
                val b = buf.get(o + 2).toInt() and 0xFF
                if (abs(r - p[2]) > 30 || abs(g - p[3]) > 30 || abs(b - p[4]) > 30) return false
            }
            return true
        }
        return when {
            hit(L.NOFUNDS) -> Bot.NOFUNDS
            hit(L.CONFIRM_NUM) -> Bot.CONFIRM_NUM
            hit(L.CONFIRM_SVC) -> Bot.CONFIRM_SVC
            else -> Bot.NONE
        }
    }

    fun release() {
        try { vd.release() } catch (e: Exception) {}
        try { reader.close() } catch (e: Exception) {}
        try { mp.stop() } catch (e: Exception) {}
        thread.quitSafely()
    }
}
